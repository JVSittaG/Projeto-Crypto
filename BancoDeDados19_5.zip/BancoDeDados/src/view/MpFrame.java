
package view;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import model.Investidor;




public class MpFrame extends javax.swing.JFrame {

 
    public MpFrame() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btSaldo = new javax.swing.JButton();
        btExtrato = new javax.swing.JButton();
        btSair = new javax.swing.JButton();
        btSaque = new javax.swing.JButton();
        btDeposito = new javax.swing.JButton();
        btComprar = new javax.swing.JButton();
        lblMenuConta = new javax.swing.JLabel();
        lblMenuCb = new javax.swing.JLabel();
        btAtualizarCrypto = new javax.swing.JButton();
        btVender = new javax.swing.JButton();
        jTextFieldMenu = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btSaldo.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btSaldo.setText("Saldo");

        btExtrato.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btExtrato.setText("Extrato");

        btSair.setFont(new java.awt.Font("Comic Sans MS", 0, 8)); // NOI18N
        btSair.setText("SAIR");

        btSaque.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btSaque.setText("Saque");

        btDeposito.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btDeposito.setText("Deposito");

        btComprar.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btComprar.setText("Comprar");

        lblMenuConta.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        lblMenuConta.setText("Conta: ");

        lblMenuCb.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        lblMenuCb.setText("Crypto: ");

        btAtualizarCrypto.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btAtualizarCrypto.setText("Atualizar");

        btVender.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        btVender.setText("Vender");

        jTextFieldMenu.setFont(new java.awt.Font("Comic Sans MS", 0, 36)); // NOI18N
        jTextFieldMenu.setText("Crypto Bank");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btSair))
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblMenuConta, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(lblMenuCb))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(123, 123, 123)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(87, 87, 87)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btExtrato, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btVender, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(84, 84, 84)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btAtualizarCrypto, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btDeposito, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
                        .addComponent(btSaque, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78))))
            .addGroup(layout.createSequentialGroup()
                .addGap(276, 276, 276)
                .addComponent(jTextFieldMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextFieldMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(lblMenuConta, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btExtrato, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btDeposito, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btSaque, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(87, 87, 87)
                .addComponent(lblMenuCb, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btVender, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btAtualizarCrypto, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(121, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btSair))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public JButton getBtAtualizarCrypto() {
        return btAtualizarCrypto;
    }

    public void setBtAtualizarCrypto(JButton btAtualizarCrypto) {
        this.btAtualizarCrypto = btAtualizarCrypto;
    }

    public JButton getBtComprar() {
        return btComprar;
    }

    public void setBtComprar(JButton btComprar) {
        this.btComprar = btComprar;
    }

    public JButton getBtDeposito() {
        return btDeposito;
    }

    public void setBtDeposito(JButton btDeposito) {
        this.btDeposito = btDeposito;
    }

    public JButton getBtExtrato() {
        return btExtrato;
    }

    public void setBtExtrato(JButton btExtrato) {
        this.btExtrato = btExtrato;
    }

    public JButton getBtSair() {
        return btSair;
    }

    public void setBtSair(JButton btSair) {
        this.btSair = btSair;
    }

    public JButton getBtSaldo() {
        return btSaldo;
    }

    public void setBtSaldo(JButton btSaldo) {
        this.btSaldo = btSaldo;
    }

    public JButton getBtSaque() {
        return btSaque;
    }

    public void setBtSaque(JButton btSaque) {
        this.btSaque = btSaque;
    }

    public JButton getBtVender() {
        return btVender;
    }

    public void setBtVender(JButton btVender) {
        this.btVender = btVender;
    }

    public JLabel getLblMenuCb() {
        return lblMenuCb;
    }

    public void setLblMenuCb(JLabel lblMenuCb) {
        this.lblMenuCb = lblMenuCb;
    }

    public JLabel getLblMenuConta() {
        return lblMenuConta;
    }

    public void setLblMenuConta(JLabel lblMenuConta) {
        this.lblMenuConta = lblMenuConta;
    }

    public JTextField getjTextFieldMenu() {
        return jTextFieldMenu;
    }

    public void setjTextFieldMenu(JTextField jTextFieldMenu) {
        this.jTextFieldMenu = jTextFieldMenu;
    }

    

    
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAtualizarCrypto;
    private javax.swing.JButton btComprar;
    private javax.swing.JButton btDeposito;
    private javax.swing.JButton btExtrato;
    private javax.swing.JButton btSair;
    private javax.swing.JButton btSaldo;
    private javax.swing.JButton btSaque;
    private javax.swing.JButton btVender;
    private javax.swing.JTextField jTextFieldMenu;
    private javax.swing.JLabel lblMenuCb;
    private javax.swing.JLabel lblMenuConta;
    // End of variables declaration//GEN-END:variables

    
}
